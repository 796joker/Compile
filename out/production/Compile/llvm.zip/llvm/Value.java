package llvm;

public class Value {
}
