package llvm;

public class ConstInt extends Const{
}
