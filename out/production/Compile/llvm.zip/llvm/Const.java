package llvm;

public class Const extends Value{
}
