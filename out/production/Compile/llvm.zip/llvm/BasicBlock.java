package llvm;

public class BasicBlock extends Value {

}
