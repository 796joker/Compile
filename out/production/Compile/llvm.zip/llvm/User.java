package llvm;

public class User extends Value{
}
