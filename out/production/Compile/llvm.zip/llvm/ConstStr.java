package llvm;

public class ConstStr extends Const{
}
