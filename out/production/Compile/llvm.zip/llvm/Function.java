package llvm;

public class Function extends Value{
}
